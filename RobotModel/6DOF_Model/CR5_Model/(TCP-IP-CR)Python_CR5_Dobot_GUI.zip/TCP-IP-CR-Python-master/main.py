from ui import RobotUI

robot_ui = RobotUI()

robot_ui.pack()
robot_ui.mainloop()